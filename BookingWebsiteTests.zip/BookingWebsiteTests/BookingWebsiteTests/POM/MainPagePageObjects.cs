﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System;
using System.Collections.Generic;
using System.Text;

namespace BookingWebsiteTests.PageObjects
{
    class MainPagePageObjects
    {
        private IWebDriver _webDriver;
        private readonly By _selectLanguageButton = By.XPath("//button[@data-modal-id='language-selection']");
        private readonly By _selectEngUS = By.XPath("//a[@data-lang='en-us']");
        private readonly By _selectCurrencyButton = By.XPath("//button[@data-modal-header-async-type='currencyDesktop']");
        private readonly By _selectUsd = By.XPath("//a[@data-modal-header-async-url-param='changed_currency=1&selected_currency=USD&top_currency=1']");
        private readonly By _searchCityField = By.XPath("//input[@type='search']");
        private const string _destinationNewYork = "New York";
        private readonly By _searchButton = By.CssSelector(".sb-searchbox__button");
        private readonly By _dateField = By.XPath("//span[@class='sb-date-field__icon sb-date-field__icon-btn bk-svg-wrapper calendar-restructure-sb']");
        private readonly By _nextMonthClick = By.XPath("//div[@data-bui-ref='calendar-next']");
        private readonly By _findDecember1 = By.XPath("//td[@data-date='2022-12-01']");
        private readonly By _findDecember31 = By.XPath("//td[@data-date='2022-12-31']");
        private readonly By _assertDecember1 = By.XPath("//button[text()='Thursday, December 1, 2022']");
        private readonly By _assertDecember31 = By.XPath("//button[text()='Saturday, December 31, 2022']");
        private readonly By _attractionsButton = By.XPath("//a[@data-decider-header='attractions']");
        private readonly By _selectLondonAttractions = By.XPath("//div[text()='London']");
        private readonly By _filterMuseums = By.XPath("//span[text()='Museums']");
        private readonly By _lowestPriceFilter = By.XPath("//li[text()='Lowest price']");
        private readonly By _selectMuseum = By.XPath("//a[@title='The Painted Hall Admission']");
        private readonly By _placeAssert = By.XPath("//div[@class='css-wmibkd']");
        private readonly By _covid = By.XPath("//a[@href='#covid']");
        private readonly By _assertNewYork1 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[3]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        private readonly By _assertNewYork2 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[4]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        private readonly By _assertNewYork3 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[6]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        private readonly By _assertNewYork4 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[8]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        private readonly By _assertNewYork5 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[10]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        private readonly By _assertNewYork6 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[12]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        private readonly By _assertNewYork7 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[14]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        private readonly By _assertNewYork8 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[15]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        private readonly By _assertNewYork9 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[17]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        private readonly By _assertNewYork10 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[19]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        private readonly By _assertNewYork11 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[20]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        private readonly By _assertNewYork12 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[22]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        private readonly By _assertNewYork13 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[23]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        private readonly By _assertNewYork14 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[24]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        private readonly By _assertNewYork15 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[25]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        private readonly By _assertNewYork16 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[27]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        private readonly By _assertNewYork17 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[28]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        private readonly By _assertNewYork18 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[30]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        private readonly By _assertNewYork19 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[32]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        private readonly By _assertNewYork20 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[34]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        private readonly By _assertNewYork21 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[36]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        private readonly By _assertNewYork22 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[38]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        private readonly By _assertNewYork23 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[40]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        private readonly By _assertNewYork24 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[41]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        private readonly By _assertNewYork25 = By.XPath("//*[@id='search_results_table']/div[2]/div/div/div/div[3]/div[43]/div[1]/div[2]/div/div[1]/div[1]/div/div[2]/div/a/span/span[1]");
        public MainPagePageObjects(IWebDriver webdriver)
        {
            _webDriver = webdriver;
        }
        public MainPagePageObjects SelectEnglishUsVersion()
        {
            WaitUntil.WaitElement(_webDriver, _selectLanguageButton);
            _webDriver.FindElement(_selectLanguageButton).Click();
            WaitUntil.WaitElement(_webDriver, _selectEngUS);
            _webDriver.FindElement(_selectEngUS).Click();
            return new MainPagePageObjects(_webDriver);
        }
        public MainPagePageObjects SelectCurrencyUSD()
        {
            WaitUntil.WaitElement(_webDriver, _selectCurrencyButton);
            _webDriver.FindElement(_selectCurrencyButton).Click();
            WaitUntil.WaitElement(_webDriver, _selectUsd);
            _webDriver.FindElement(_selectUsd).Click();
            return new MainPagePageObjects(_webDriver);
        }
        public MainPagePageObjects EnterDestinationNewYork()
        {
            WaitUntil.WaitElement(_webDriver, _searchCityField);
            _webDriver.FindElement(_searchCityField).Click();
            WaitUntil.WaitElement(_webDriver, _searchCityField);
            _webDriver.FindElement(_searchCityField).SendKeys(_destinationNewYork);
            return new MainPagePageObjects(_webDriver);
        }
        public MainPagePageObjects SelectDate()
        {
            WaitUntil.WaitElement(_webDriver, _dateField);
            _webDriver.FindElement(_dateField).Click();
            WaitUntil.WaitElement(_webDriver, _nextMonthClick);
            _webDriver.FindElement(_nextMonthClick).Click();
            _webDriver.FindElement(_nextMonthClick).Click();
            WaitUntil.WaitElement(_webDriver, _findDecember1);
            _webDriver.FindElement(_findDecember1).Click();
            _webDriver.FindElement(_findDecember31).Click();
            WaitUntil.WaitElement(_webDriver, _searchButton);
            _webDriver.FindElement(_searchButton).Click();
            string december1 = _webDriver.FindElement(_assertDecember1).Text;
            string december31 = _webDriver.FindElement(_assertDecember31).Text;
            Assert.AreEqual("1\r\nThursday, December 1, 2022", december1);
            Assert.AreEqual("31\r\nSaturday, December 31, 2022", december31);
            return new MainPagePageObjects(_webDriver);
        }
        public MainPagePageObjects IsCityNewYork()
        {
            string actual = _webDriver.FindElement(_assertNewYork1).Text;
            string[] subs = actual.Split(',');
            Assert.AreEqual(" New York", subs[1].ToString());
            string actual2 = _webDriver.FindElement(_assertNewYork2).Text;
            string[] subs2 = actual2.Split(',');
            Assert.AreEqual(" New York", subs2[1].ToString());
            string actual3 = _webDriver.FindElement(_assertNewYork3).Text;
            string[] subs3 = actual3.Split(',');
            Assert.AreEqual(" New York", subs3[1].ToString());
            string actual4 = _webDriver.FindElement(_assertNewYork4).Text;
            string[] subs4 = actual4.Split(',');
            Assert.AreEqual(" New York", subs4[1].ToString());
            string actual5 = _webDriver.FindElement(_assertNewYork5).Text;
            string[] subs5 = actual5.Split(',');
            Assert.AreEqual(" New York", subs5[1].ToString());
            string actual6 = _webDriver.FindElement(_assertNewYork6).Text;
            string[] subs6 = actual2.Split(',');
            Assert.AreEqual(" New York", subs6[1].ToString());
            string actual7 = _webDriver.FindElement(_assertNewYork7).Text;
            string[] subs7 = actual7.Split(',');
            Assert.AreEqual(" New York", subs7[1].ToString());
            string actual8 = _webDriver.FindElement(_assertNewYork8).Text;
            string[] subs8 = actual8.Split(',');
            Assert.AreEqual(" New York", subs8[1].ToString());
            string actual9 = _webDriver.FindElement(_assertNewYork9).Text;
            string[] subs9 = actual9.Split(',');
            Assert.AreEqual(" New York", subs9[1].ToString());
            string actual10 = _webDriver.FindElement(_assertNewYork10).Text;
            string[] subs10 = actual10.Split(',');
            Assert.AreEqual(" New York", subs10[1].ToString());
            string actual11 = _webDriver.FindElement(_assertNewYork11).Text;
            string[] subs11 = actual11.Split(',');
            Assert.AreEqual(" New York", subs11[1].ToString());
            string actual12 = _webDriver.FindElement(_assertNewYork12).Text;
            string[] subs12 = actual12.Split(',');
            Assert.AreEqual(" New York", subs12[1].ToString());
            string actual13 = _webDriver.FindElement(_assertNewYork13).Text;
            string[] subs13 = actual13.Split(',');
            Assert.AreEqual(" New York", subs13[1].ToString());
            string actual14 = _webDriver.FindElement(_assertNewYork14).Text;
            string[] subs14 = actual14.Split(',');
            Assert.AreEqual(" New York", subs14[1].ToString());
            string actual15 = _webDriver.FindElement(_assertNewYork15).Text;
            string[] subs15 = actual15.Split(',');
            Assert.AreEqual(" New York", subs15[1].ToString());
            string actual16 = _webDriver.FindElement(_assertNewYork16).Text;
            string[] subs16 = actual16.Split(',');
            Assert.AreEqual(" New York", subs16[1].ToString());
            /*string actual9 = _webDriver.FindElement(_assertNewYork9).Text;
            string[] subs9 = actual9.Split(',');
            Assert.AreEqual(" New York", subs9[1].ToString());
            string actual9 = _webDriver.FindElement(_assertNewYork9).Text;
            string[] subs9 = actual9.Split(',');
            Assert.AreEqual(" New York", subs9[1].ToString());
            string actual9 = _webDriver.FindElement(_assertNewYork9).Text;
            string[] subs9 = actual9.Split(',');
            Assert.AreEqual(" New York", subs9[1].ToString());
            string actual9 = _webDriver.FindElement(_assertNewYork9).Text;
            string[] subs9 = actual9.Split(',');
            Assert.AreEqual(" New York", subs9[1].ToString());
            string actual9 = _webDriver.FindElement(_assertNewYork9).Text;
            string[] subs9 = actual9.Split(',');
            Assert.AreEqual(" New York", subs9[1].ToString());
            string actual9 = _webDriver.FindElement(_assertNewYork9).Text;
            string[] subs9 = actual9.Split(',');
            Assert.AreEqual(" New York", subs9[1].ToString());
            string actual9 = _webDriver.FindElement(_assertNewYork9).Text;
            string[] subs9 = actual9.Split(',');
            Assert.AreEqual(" New York", subs9[1].ToString());
            string actual9 = _webDriver.FindElement(_assertNewYork9).Text;
            string[] subs9 = actual9.Split(',');
            Assert.AreEqual(" New York", subs9[1].ToString());
            string actual9 = _webDriver.FindElement(_assertNewYork9).Text;
            string[] subs9 = actual9.Split(',');
            Assert.AreEqual(" New York", subs9[1].ToString());*/
            return new MainPagePageObjects(_webDriver);
        }
        public MainPagePageObjects AttractionsPage()
        {
            WaitUntil.WaitElement(_webDriver, _attractionsButton);
            _webDriver.FindElement(_attractionsButton).Click();
            return new MainPagePageObjects(_webDriver);
        }
        public MainPagePageObjects SelectCityInAttractionsLondon()
        {
            WaitUntil.WaitElement(_webDriver, _selectLondonAttractions);
            _webDriver.FindElement(_selectLondonAttractions).Click();
            return new MainPagePageObjects(_webDriver);
        }
        public MainPagePageObjects MuseumsFilterSelect()
        {
            WaitUntil.WaitElement(_webDriver, _filterMuseums);
            _webDriver.FindElement(_filterMuseums).Click();
            WaitUntil.WaitElement(_webDriver, _lowestPriceFilter);
            _webDriver.FindElement(_lowestPriceFilter).Click();
            return new MainPagePageObjects(_webDriver);
        }
        public MainPagePageObjects SelectMuseumFromList()
        {
            WaitUntil.WaitElement(_webDriver, _selectMuseum);
            _webDriver.FindElement(_selectMuseum).Click();
            WaitUntil.WaitElement(_webDriver, _covid);
            _webDriver.FindElement(_covid).Click();

           /* string place =_webDriver.FindElement(_placeAssert).Text;
            Assert.AreEqual("The Painted Hall Admission", place);*/
            return new MainPagePageObjects(_webDriver);
        }
    }
}
